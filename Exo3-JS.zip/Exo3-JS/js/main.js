// Réaliser les conditions if/else
// Ecrire un script demandant de l’utilisateur d’entrer son âge et de contrôler la validité de l’âge entré (si l’âge est erroné afficher un message d’erreur et redemander de saisir l’âge). 

let age = parseInt(prompt("Quel est votre âge ?: "))

function check(){
if (age > 0){
        alert(`Vous avez: ${age} `);
    }
else {
    alert("La valeur est erronnée. Veuillez ressaisir à nouveau:");
}
}
check();
